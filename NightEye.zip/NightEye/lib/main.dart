import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:osa/next_page.dart';
import 'package:osa/splash.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Welcome Page',
      home: MySplach(),
    );
  }
}

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  Timer? _timer;
  FlutterTts flutterTts = FlutterTts();
  TextEditingController textEditingController = TextEditingController();

  speak(String text) async {
    await flutterTts.setLanguage("en-US"); // Set the language (optional)
    await flutterTts.setPitch(1.0); // Set the pitch (optional)
    await flutterTts.speak(text); // Speak the text
  }

  @override
  void initState() {
    super.initState();
    // Set up a timer to navigate to the next page after 30 seconds
    _timer = Timer(const Duration(seconds: 30), _navigateToNextPage);
    speak(
        "Welcome to NightEye! We will assist you in detecting and reading the words from books or street signs. All you have to do is choose an image from your gallery or open the camera and scan the words you want to read. Hope you enjoy with us!");
  }

  void _navigateToNextPage() {
    _timer?.cancel();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const NextPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NightEye', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color.fromARGB(255, 164, 88, 214), // Dark purple
        actions: [
          IconButton(
            onPressed: () {},
            icon: SizedBox(
              width: 70, // Adjust size as needed
              height: 60, // Adjust size as needed
              child: Image.asset('assets/icon/logo.png'), // Adjust image path
            ),
          ),
        ],
      ),
      backgroundColor: const Color.fromARGB(255, 235, 216, 249), // Light purple
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 200),
            const Text(
              'Welcome to NightEye!\n'
              'We will assist you in detecting and reading the words from books or street signs.\n'
              'All you have to do is choose an image from your gallery or OPEN the camera and scan the words you want to read.\n'
              'HOPE YOU ENJOY WITH US!',
              style: TextStyle(fontSize: 20),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            Align(
              alignment: Alignment.bottomRight,
              child: ElevatedButton.icon(
                onPressed: () {
                  flutterTts.stop();
                  _navigateToNextPage();
                },
                icon: const Icon(Icons.arrow_forward),
                label: const Text('Skip'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
