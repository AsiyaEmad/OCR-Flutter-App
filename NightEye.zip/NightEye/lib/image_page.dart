import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';

FlutterTts flutterTts = FlutterTts();

class ImagePage extends StatefulWidget {
  ImagePage({super.key, required this.imageBytes, required this.detectedWords});

  Uint8List imageBytes;
  List<dynamic> detectedWords;

  @override
  _ImagePageState createState() => _ImagePageState();
}

class _ImagePageState extends State<ImagePage> {
  @override
  void initState() {
    super.initState();
    // Trigger the speech after the frame is rendered
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (widget.detectedWords.isNotEmpty) {
        speakList();
      }
    });
  }

  // Function to speak each word in the list with a pause
  Future<void> speakList() async {
    await flutterTts.setLanguage("en-US"); // Configure TTS options here
    await flutterTts.setPitch(1.0);
    for (var item in widget.detectedWords) {
      String text = item.toString(); // Ensuring the item is a string
      await flutterTts.speak(text);
      await flutterTts.awaitSpeakCompletion(true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('Result', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color.fromARGB(255, 164, 88, 214),
        actions: [
          IconButton(
            onPressed: () {}, // Add your action here
            icon: SizedBox(
              width: 70, // Adjust size as needed
              height: 60, // Adjust size as needed
              child: Image.asset('assets/icon/logo.png'), // Adjust image path
            ),
          ),
        ],
      ),
      backgroundColor: const Color.fromARGB(255, 235, 216, 249),
      body: Stack(
        children: [
          Positioned(
            left: 12,
            bottom: 12,
            child: ElevatedButton(
              onPressed: () {
                flutterTts.stop();
                Navigator.pop(context);
              },
              child: const Text('Back'),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 450,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20.0),
                  bottomRight: Radius.circular(20.0),
                ),
              ),
              child: Center(
                child: Image.memory(
                  widget.imageBytes,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Positioned(
            top: 460,
            left: 0,
            right: 0,
            bottom: 50,
            child: ListView.builder(
              itemCount: widget.detectedWords.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(widget.detectedWords[index].toString()),
                  onTap: () {
                    Clipboard.setData(ClipboardData(
                        text: widget.detectedWords[index].toString()));
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content:
                              Text('Copied "${widget.detectedWords[index]}"')),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
