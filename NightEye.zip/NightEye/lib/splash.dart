import 'dart:async';
import 'package:flutter/material.dart';
import 'package:osa/main.dart';

class MySplach extends StatefulWidget {
  const MySplach({super.key});

  @override
  State<MySplach> createState() => _MySplachState();
}

class _MySplachState extends State<MySplach> {
  @override
  void initState() {
    // TODO: implement initState
    Timer(const Duration(seconds: 2), () {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => const WelcomePage()));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset("assets/icon/SS.png"),
      ),
    );
  }
}
