import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:osa/image_page.dart';

class NextPage extends StatefulWidget {
  const NextPage({super.key});

  @override
  _NextPageState createState() => _NextPageState();
}

class _NextPageState extends State<NextPage> {
  final ImagePicker _picker = ImagePicker();
  //File? _image;

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);
    if (pickedFile != null) {
      await sendPhoto(File(pickedFile.path).path);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ButtonStyle buttonStyle = ElevatedButton.styleFrom(
      minimumSize: const Size(300, 75), // Adjust width and height
      textStyle: const TextStyle(fontSize: 20), // Adjust text size
    );

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // Remove back button
        title: const Text('Start Detection',
            style: TextStyle(color: Colors.white)),
        backgroundColor: const Color.fromARGB(255, 164, 88, 214), // Dark purple
        actions: [
          IconButton(
            onPressed: () {}, // Add your action here
            icon: SizedBox(
              width: 70, // Adjust size as needed
              height: 60, // Adjust size as needed
              child: Image.asset('assets/icon/logo.png'), // Adjust image path
            ),
          ),
        ],
      ),
      backgroundColor: const Color.fromARGB(255, 235, 216, 249), // Light purple
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              onPressed: () => _pickImage(ImageSource.camera),
              icon: const Icon(Icons.camera),
              label: const Text('       Open Camera      '),
              style: buttonStyle,
            ),
            const SizedBox(height: 50),
            ElevatedButton.icon(
              onPressed: () => _pickImage(ImageSource.gallery),
              icon: const Icon(Icons.photo),
              label: const Text(' Choose From Gallery'),
              style: buttonStyle,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> sendPhoto(String imgFile) async {
    log(imgFile);
    // Instantiate Dio
    Dio dio = Dio();
    // Set API endpoint
    String url = 'http://localhost:5000/upload';

    // Create FormData object to hold photo
    FormData formData = FormData.fromMap({
      'image_file':
          await MultipartFile.fromFile(imgFile, filename: 'photo.jpg'),
      // Add any additional fields or data here
    });

    try {
      // Send POST request with FormData containing the photo
      Response response = await dio.post(url, data: formData);
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ImagePage(
              detectedWords: response.data['detected_words'],
              imageBytes: base64Decode(response.data['image_base64'])),
        ),
      );
      // Handle response
      print('Response status: ${response.statusCode}');
      print('Response data: ${response.data}');
    } catch (e) {
      // Handle error
      print('Error sending photo: $e');
    }
  }
}
