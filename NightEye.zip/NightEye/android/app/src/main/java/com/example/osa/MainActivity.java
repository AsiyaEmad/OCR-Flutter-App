package com.example.osa;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
